import React from "react";
import "./styles.css";
import moment from "moment";
import { RenderTransactionList } from "./RenderTransactionList";
export default class App extends React.PureComponent {
  state = {
    amount: "",
    transactionList: [],
    totalReward: 0
  };

  handleOnChangeAMount = evt => {
    const { name, value } = evt.target;
    this.setState({
      [name]: value
    });
  };

  handleSubmitAmount = () => {
    const { amount, transactionList } = this.state;
    const newTransactionList = [...transactionList];
    let rewardPoint = 0;
    let totalReward = 0;
    if (amount > 100) {
      rewardPoint = 2 * (amount - 100) + 1 * 50;
    } else if (amount > 49 && amount < 100) {
      rewardPoint = 0 + 1 * 50;
    }

    newTransactionList.push({
      amount,
      rewardPoint,
      transactionDate: moment().format("MMM DD, YYYY, h:mm:ss")
    });
    newTransactionList.map(item => {
      totalReward = totalReward + item.rewardPoint;
      return item;
    });
    this.setState({
      transactionList: newTransactionList,
      amount: "",
      totalReward
    });
  };

  render() {
    const { transactionList, amount, totalReward } = this.state;
    return (
      <>
        <label>Enter amount:</label>
        <input
          type="text"
          id="amount"
          name="amount"
          value={amount}
          onChange={this.handleOnChangeAMount}
        />
        <br />
        <br />
        <button type="button" onClick={this.handleSubmitAmount}>
          Submit
        </button>
        <br />
        <br />
        <RenderTransactionList
          transactionList={transactionList}
          totalReward={totalReward}
        />
      </>
    );
  }
}
