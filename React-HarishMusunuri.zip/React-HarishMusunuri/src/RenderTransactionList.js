import React from "react";
import { RenderListItem } from "./RenderListItem";
export const RenderTransactionList = props => {
  const { transactionList, totalReward } = props;
  if (transactionList && transactionList.length > 0) {
    return (
      <>
        <table>
          <thead>
            <tr>
              <th style={{ width: "130px" }}>{"Transaction Date"}</th>
              <th style={{ width: "130px" }}>{"Amount"}</th>
              <th style={{ width: "130px" }}>{"Reward Point"}</th>
            </tr>
          </thead>
          <tbody>
            <RenderListItem {...props} />
          </tbody>
        </table>
        <br /> <br />
        <span>{`Total reward point is ${totalReward}`}</span>
      </>
    );
  }

  return null;
};
