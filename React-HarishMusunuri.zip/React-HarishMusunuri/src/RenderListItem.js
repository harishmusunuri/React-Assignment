import React from "react";
import moment from "moment";
export const RenderListItem = props => {
  const { transactionList } = props;
  return transactionList.map((item, index) => {
    return (
      <tr key={index}>
        <td style={{ width: "130px" }}>
          {moment(item.transactionDate).format("MMM DD, YYYY")}
        </td>
        <td style={{ width: "130px" }}>{item.amount}</td>
        <td style={{ width: "130px" }}>{item.rewardPoint}</td>
      </tr>
    );
  });
};
